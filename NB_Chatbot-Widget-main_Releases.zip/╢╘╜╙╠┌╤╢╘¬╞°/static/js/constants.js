// 腾讯元气 API 的请求地址
const yuanqi_api_url = 'https://yuanqi.tencent.com/openapi/v1/agent/chat/completions';
// 腾讯元气 API 的授权 Token
const authorization_token = 'YOUR_TOKEN';	// 改成自己的
// 智能体 ID
const assistant_id = 'YOUR_ASSISTANT_ID';	//改成自己的
// 生成一个唯一的用户 ID
const user_id = uuidv4();